# Sporty Shoes E-commerce Website

This project is a prototype for an e-commerce website for Sporty Shoes, a company that manufactures and sells sports shoes. The website will allow users to browse and purchase products, and an admin to manage the website.

## Features

- User registration and login
- Browsing and purchasing products
- Admin login
- Admin can manage products, including categorizing them
- Admin can browse the list of users and search users
- Admin can see purchase reports filtered by date and category

## Technologies Used

- Java
- Spring Boot
- Thymeleaf
- MySQL

## Getting Started

1. Clone the repository to your local machine.
2. Navigate to the project directory.
3. Run `mvn spring-boot:run` to start the application.
4. Access the application at `http://localhost:8080`.

## Project Structure

```
.
├── README.md
├── .gitignore
├── pom.xml
├── src
│   ├── main
│   │   ├── java
│   │   │   ├── com
│   │   │   │   ├── sportyshoes
│   │   │   │   │   ├── SportyShoesApplication.java
│   │   │   │   │   ├── controller
│   │   │   │   │   │   ├── AdminController.java
│   │   │   │   │   │   ├── ProductController.java
│   │   │   │   │   │   ├── UserController.java
│   │   │   │   │   ├── model
│   │   │   │   │   │   ├── Product.java
│   │   │   │   │   │   ├── User.java
│   │   │   │   │   ├── repository
│   │   │   │   │   │   ├── ProductRepository.java
│   │   │   │   │   │   ├── UserRepository.java
│   │   ├── resources
│   │   │   ├── application.properties
│   │   │   ├── templates
```

## Contributing

Pull requests are welcome. For major changes, please open an issue first to discuss what you would like to change.

## License

[MIT](https://choosealicense.com/licenses/mit/)
